package net.mcreator.dedsafio3.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.mcreator.dedsafio3.client.gui.TikiGuiScreen;
import net.mcreator.dedsafio3.client.renderer.HydraRenderer;
import net.mcreator.dedsafio3.client.renderer.RevilBossRenderer;
import net.mcreator.dedsafio3.client.renderer.TikiGuardianRenderer;
import net.mcreator.dedsafio3.init.Dedsafio3ModEntities;
import net.mcreator.dedsafio3.init.Dedsafio3ModMenus;
import net.mcreator.dedsafio3.network.Dedsafio3ModNetwork;
import net.mcreator.dedsafio3.network.Dedsafio3ModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.MenuScreens;
import org.lwjgl.glfw.GLFW;

public class Dedsafio3ModClient implements ClientModInitializer {
    /** Tecla "G" (key.dedsafio3.g, "Experimental"), categoría key.categories.dedsafio3: abre el panel de Tiki. */
    public static KeyMapping G_KEY;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(Dedsafio3ModEntities.TIKI_GUARDIAN, TikiGuardianRenderer::new);
        EntityRendererRegistry.register(Dedsafio3ModEntities.REVIL_BOSS, RevilBossRenderer::new);
        EntityRendererRegistry.register(Dedsafio3ModEntities.HYDRA, HydraRenderer::new);

        MenuScreens.register(Dedsafio3ModMenus.TIKI_GUI, TikiGuiScreen::new);

        G_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.dedsafio3.g", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.dedsafio3"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (G_KEY.consumeClick()) {
                if (client.screen == null && client.player != null) {
                    ClientPlayNetworking.send(new Dedsafio3ModNetwork.GPressPayload(0, 0));
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(Dedsafio3ModNetwork.MapVariablesSyncPayload.TYPE, (payload, context) -> {
            Dedsafio3ModVariables.MapVariables.clientSide.TikiWalk = payload.tikiWalk();
            Dedsafio3ModVariables.MapVariables.clientSide.TikiDash = payload.tikiDash();
        });
    }
}
