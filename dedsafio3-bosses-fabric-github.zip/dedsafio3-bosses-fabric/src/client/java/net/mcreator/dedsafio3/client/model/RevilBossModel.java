package net.mcreator.dedsafio3.client.model;

import net.mcreator.dedsafio3.entity.RevilBossEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class RevilBossModel extends GeoModel<RevilBossEntity> {
    @Override
    public ResourceLocation getAnimationResource(RevilBossEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "animations/reviillboss.animation.json");
    }

    @Override
    public ResourceLocation getModelResource(RevilBossEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "geo/reviillboss.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(RevilBossEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "textures/entities/" + entity.getTexture() + ".png");
    }
}
