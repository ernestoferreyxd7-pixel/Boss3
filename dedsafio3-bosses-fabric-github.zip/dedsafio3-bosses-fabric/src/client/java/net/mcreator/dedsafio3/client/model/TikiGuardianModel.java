package net.mcreator.dedsafio3.client.model;

import net.mcreator.dedsafio3.entity.TikiGuardianEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class TikiGuardianModel extends GeoModel<TikiGuardianEntity> {
    @Override
    public ResourceLocation getAnimationResource(TikiGuardianEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "animations/tikiguardian.animation.json");
    }

    @Override
    public ResourceLocation getModelResource(TikiGuardianEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "geo/tikiguardian.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(TikiGuardianEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "textures/entities/" + entity.getTexture() + ".png");
    }
}
