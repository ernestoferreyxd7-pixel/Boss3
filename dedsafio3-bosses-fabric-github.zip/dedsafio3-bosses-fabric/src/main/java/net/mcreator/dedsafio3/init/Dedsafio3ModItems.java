package net.mcreator.dedsafio3.init;

import net.mcreator.dedsafio3.Dedsafio3Mod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

public class Dedsafio3ModItems {
    // Colores (primario, secundario) tomados de los ForgeSpawnEggItem originales.
    public static final Item HYDRA_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM,
            Dedsafio3Mod.id("hydra_spawn_egg"),
            new SpawnEggItem(Dedsafio3ModEntities.HYDRA, -16737844, -16750849, new Item.Properties()));

    public static final Item REVIL_BOSS_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM,
            Dedsafio3Mod.id("revil_boss_spawn_egg"),
            new SpawnEggItem(Dedsafio3ModEntities.REVIL_BOSS, -26266, -13421773, new Item.Properties()));

    public static final Item TIKI_GUARDIAN_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM,
            Dedsafio3Mod.id("tiki_guardian_spawn_egg"),
            new SpawnEggItem(Dedsafio3ModEntities.TIKI_GUARDIAN, -15577595, -6579968, new Item.Properties()));

    public static void register() {
        // Fuerza la carga de la clase (los campos estáticos hacen el registro).
    }
}
