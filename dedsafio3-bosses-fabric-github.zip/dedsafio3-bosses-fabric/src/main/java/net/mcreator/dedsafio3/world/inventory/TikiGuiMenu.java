package net.mcreator.dedsafio3.world.inventory;

import net.mcreator.dedsafio3.init.Dedsafio3ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.HashMap;

/** Menú sin slots del panel "Tiki King Control Panel" (TikiGuiMenu original). */
public class TikiGuiMenu extends AbstractContainerMenu {
    public static final HashMap<String, Object> guistate = new HashMap<>();
    public final Level world;
    public final Player entity;
    public int x, y, z;

    public TikiGuiMenu(int id, Inventory inv, BlockPos pos) {
        super(Dedsafio3ModMenus.TIKI_GUI, id);
        this.entity = inv.player;
        this.world = inv.player.level();
        if (pos != null) {
            this.x = pos.getX();
            this.y = pos.getY();
            this.z = pos.getZ();
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player playerIn, int index) {
        return ItemStack.EMPTY;
    }
}
