package net.mcreator.dedsafio3.procedures;

import net.mcreator.dedsafio3.network.Dedsafio3ModVariables;
import net.minecraft.world.level.LevelAccessor;

public class TWDisableProcedure {
    public static void execute(LevelAccessor world) {
        Dedsafio3ModVariables.MapVariables.get(world).TikiWalk = false;
        Dedsafio3ModVariables.MapVariables.get(world).syncData(world);
    }
}
