# Dedsafio 3 Bosses — port parcial a Fabric 1.21.1

Port de **Hydra**, **Reviil (RevilBoss)** y **Tiki Guardian** desde *Dedsafio 3 Fan Project 0.0.9* (Forge 1.20.1).
Nada más del mod original se porta.

## ESTADO: SIN COMPILAR
Este proyecto se escribió a partir del análisis del bytecode original (`javap`) en un entorno **sin red**, sin Gradle y sin
Minecraft/Fabric/GeckoLib. Por eso **no se ha compilado ni probado en juego** y no hay JAR.
Lo verificado: (1) los 13 assets son idénticos byte a byte a los originales; (2) todos los .java pasan el parseo de javac.
Lo no verificado: que compile contra las APIs reales de 1.21.1 / GeckoLib, y el comportamiento en juego.

## Compilar
Requiere JDK 21 y red.

    gradle wrapper --gradle-version 8.10.2   # o usa tu Gradle 8.10+
    ./gradlew build                           # el JAR queda en build/libs/dedsafio3-bosses-0.0.9-fabric.1.jar

Envía los errores de compilación y se corrigen por rondas.

## Versiones a confirmar (gradle.properties / build.gradle)
No pude consultarlas sin red. Ajusta si no resuelven:
- `fabric_api_version=0.105.0+1.21.1`
- `loader_version=0.16.9`
- `geckolib_version=4.7.1` (artefacto `geckolib-fabric-1.21.1`, repo cloudsmith de GeckoLib)
- Loom `1.8-SNAPSHOT`

## Dependencias para jugadores y servidor
Fabric API y GeckoLib. Para no pedir GeckoLib aparte, descomenta la línea `include` en `build.gradle` (jar-in-jar).

## Qué se portó (fiel al bytecode original)
| | Hydra | RevilBoss | TikiGuardian |
|---|---|---|---|
| Vida / Ataque / Velocidad | 1000 / 10 / 0.0 | 100 / 20 / 0.3 | 10 / 3 / 0.3 |
| Armadura / Follow range | 0 / 16 | 0 / 16 | 0 / 16 |
| Hitbox registrada | 2 × 20 | 3 × 6.6 | 4.5 × 5.0 |
| Escala (dimensiones / render) | 1.5 / 1.5 | 1.0 / 1.0 | 1.0 / 1.0 |
| Sombra | 2.0 | 0.5 | 3.0 |
| Huevo (primario, secundario) | -16737844, -16750849 | -26266, -13421773 | -15577595, -6579968 |

- IA de Hydra y Revil: MeleeAttack (1.2, alcance propio), HurtByTarget, RandomStroll 0.8, RandomLookAround, NearestAttackable(Player). Tiki no tiene goals.
- Hydra: no empujable, `doPush` y `pushEntities` anulados.
- Animaciones: controladores `movement`, `attacking`, `procedure` (transición 4), lógica idéntica al original.
- Tiki: caminar hacia el jugador (100 bloques, 0.8) y dash (40 ticks, ×1.1, 5 de daño, empuje ×2.5 +0.5 Y), controlados por las
  variables de mundo `TikiWalk` / `TikiDash` (mismo nombre de datos `dedsafio3_mapvars` y claves NBT).
- Panel "Tiki King Control Panel" con la tecla **G**: botones Walk (0), Clear walk (1), Dash (5). Invocation, Spin y Sword
  no hacían nada en el original y se dejan igual.
- IDs: `dedsafio3:hydra`, `dedsafio3:revil_boss`, `dedsafio3:tiki_guardian` y sus `_spawn_egg`.

## Pendiente de verificar
1. **Tipo de daño del dash de Tiki.** El bytecode usa `DamageTypes.f_268566_` (nombre SRG) y sin los mappings no pude
   resolverlo. Se puso `DamageTypes.MOB_ATTACK` como suposición (constante `TIKI_DASH_DAMAGE_TYPE`). Confírmalo con los
   mappings de Forge 1.20.1 y corrígelo si es otro.
2. Hydra no tiene animación `walk` y Revil/Tiki no tienen `dead` en sus JSON (así vienen en el original, no se tocó).
3. `dropExperience(null)` en `tickDeath` (la firma cambió en 1.21); no tiene efecto porque xpReward = 0.

## Diferencias de plataforma (no de comportamiento)
- `setMaxUpStep(0.6)` → atributo `STEP_HEIGHT`, cuyo valor por defecto ya es 0.6.
- `getMobType()` desaparece en 1.21 (era UNDEFINED).
- El handler `LivingTickEvent` del original se reemplaza por lógica equivalente en `tick()` de cada entidad.
- La sincronización de variables es servidor→cliente (autoridad del servidor); el original también permitía cliente→servidor.
- Como en el original, cualquier jugador puede usar el panel de Tiki (no hay comprobación de operador).

## No portado
Todo lo que no pertenece a los tres jefes: resto de entidades, bloques, ítems, teclas (salvo G), variables, comandos, etc.
